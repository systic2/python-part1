sign = "stop"
# sign 이라는 변수의 값이 문자열 stop 이라면 계속 루프를 하라는 코드
while sign == "stop":
    sign = input("현재 신호를 입력하시오 : ")

print("OK! 진행합니다.")